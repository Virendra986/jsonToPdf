1> We can test the api using url(jsonToPdfApp/jsontopdf) that accept json formate data and generate pdf file as response.
2> I also create a fronted page that we can view when project is start that have 5 view button to post the request and 5 textarea that accept only json string.
3> If user click of on first video view button and wait for 5 minutes then pdf generate of video 1 data or if he click on another video button then after five minutes the pdf generate that contains latest request json string data.

URL : jsonToPdfApp/jsontopdf
