package app.controller;
import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import app.util.GenericMethods;
import app.util.PdfGenerator;

@WebServlet("/jsontopdf")
public class jsontopdf extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 static HashMap<String,Integer> userMap; 
	 static ExecutorService executor;
    public jsontopdf() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json");
		GenericMethods genricMethodsObj = new GenericMethods();
		String requestData = genricMethodsObj.getHttpRequestBody(request);
		JSONObject jsonObj = null;
		try {
			 jsonObj = new JSONObject(requestData);
			 
		} catch (JSONException e) {
			e.printStackTrace();
			jsonObj = new JSONObject();
			try {
				jsonObj.put("responseCode","201");
				jsonObj.put("responseMessage",e.getMessage());
			} catch (JSONException e1) {
				e1.printStackTrace();
			}
			response.getWriter().write(jsonObj.toString());
			return;
		}
		
		
		try {
		
		String fileName ="questions.pdf";
		 response.setContentType("application/pdf");
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Content-Disposition","attachment;filename="+fileName);
	PdfGenerator pdfGen = new PdfGenerator();
	Document pdfDoc = new Document(PageSize.A4);
		PdfWriter.getInstance(pdfDoc,response.getOutputStream())
	  .setPdfVersion(PdfWriter.PDF_VERSION_1_7);
		
	pdfDoc.open();
		Font myfont = new Font();
	myfont.setStyle(Font.NORMAL);
	myfont.setSize(11);
		pdfDoc.add(new Paragraph("\n"));
		pdfGen.process(pdfDoc,jsonObj,myfont);
		pdfDoc.close(); 
	
		} catch (Exception e) {
			e.printStackTrace();
			try {
				response.setContentType("application/json");
				jsonObj = new JSONObject();
				jsonObj.put("responseMessage",e.getMessage());
				jsonObj.put("responseCode","201");
				response.getWriter().write(jsonObj.toString());
			} catch (JSONException e1) {
				e1.printStackTrace();
			}
		} 
		
	}
 @Override
public void init() throws ServletException {
	 userMap = new HashMap<>();
	  executor = Executors.newFixedThreadPool(5);
}
@Override
public void destroy() {
	userMap = null;
	executor.shutdownNow();
	super.destroy();
} 

 
}
