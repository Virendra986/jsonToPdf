Following are the findings and things which I have implemented while considering all the possible scenarios from the given data :

1> We can test the api using url(jsonToPdfApp/jsontopdf) that accept any type of json format data whether it is short, long or anything 
and generate pdf file as response for that specific input data.

2> I have also create a fronted page which open automatically when project will getting start that have 5 view button to post the request 
and 5 textarea that accept only json string, if you pass anything else except JSON string it will through an exception 
which states that JSON string not found since I have implemented a check in code to examine the JSON string format.

3> If user click on first video view button and wait for 5 minutes then pdf will generate for video 1 data only 
or if he click on another video button then after wait five minutes then pdf will generate that contains latest request json string data.

In other words, PDF will generate for the latest video after inactivity of 5 minutes as per the requirement.


* URL : jsonToPdfApp/jsontopdf
