package app.util;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

public class PdfGenerator {
		
	public  void process(Document pdfDoc, JSONObject json,Font myfont) throws JSONException, DocumentException {
		Iterator<?> keys = json.keys();
		while(keys.hasNext()) {
			String jsonKey=(String)keys.next();
			Object object = json.get(jsonKey);
			if (object instanceof JSONArray) {
				JSONArray list = json.getJSONArray(jsonKey);
				process(pdfDoc, list,myfont);
			} else if (object instanceof JSONObject) {
				process(pdfDoc, json.getJSONObject(jsonKey),myfont);
			} else {
				Paragraph para = new Paragraph(    json.get(jsonKey).toString() + "\n", myfont );
			    para.setAlignment(Element.ALIGN_JUSTIFIED);
			    pdfDoc.add(para);
			}
			
		}
	}

	public  void process(Document pdfDoc, JSONArray json,Font myfont) throws JSONException, DocumentException {
		for (int x = 0; x < json.length(); x++) {
			Object object = json.get(x);
			if (object instanceof JSONArray) {
				JSONArray list = json.getJSONArray(x);
				process(pdfDoc, list,myfont);
			} else if (object instanceof JSONObject) {
				process(pdfDoc, json.getJSONObject(x),myfont);
			} else {
				Paragraph para = new Paragraph(    json.get(x).toString() + "\n", myfont );
			    para.setAlignment(Element.ALIGN_JUSTIFIED);
			    pdfDoc.add(para);
				
			}

		}
		
	}

	public  void jsonTopdf(JSONObject json) throws IOException, DocumentException, JSONException {
		Document pdfDoc = new Document(PageSize.A4);
		
		PdfWriter.getInstance(pdfDoc, new FileOutputStream("/home/rapi_0033/uploads/PDF/txt1.pdf"))
		  .setPdfVersion(PdfWriter.PDF_VERSION_1_7);
		
		pdfDoc.open();
		Font myfont = new Font();
		myfont.setStyle(Font.NORMAL);
		myfont.setSize(11);
		pdfDoc.add(new Paragraph("\n"));
		process(pdfDoc,json,myfont);
		pdfDoc.close();
	}
}
